package com.example.user1.prettycool.Classes.Persons;

import com.example.user1.prettycool.R;

/**
 * Created by user1 on 18.03.2016.
 */
public class AllItems extends Item{

     AllItems(String id){
         imHeroNotMonstr=-1;
         wearing = 0;
        switch(id){
            case "B":
                name = "Bag";
                type = "???";
                 caniwear = 0;
                 itemHP = 1000;
                 addHp = 2;
                        addShield = 0;
                        addSpeed = -1;
                        addAttack = 1;
                drawableId = R.drawable.item_littlebag;
                break;
            case "Bp":
                name = "Bad Pistol";
                type = "gun";
                caniwear = 1;
                itemHP = 1000;
                addMaxHp = 500;
                addShield = 0;
                addSpeed = -1;
                addAttack = 4;
                addAttackDistance = 5;
                drawableId = R.drawable.item_badpistol;
                break;
            case "Gp":
                name = "Good Pistol";
                type = "gun";
                caniwear = 1;
                itemHP = 10000;
                addMaxHp = 100;
                addShield = 666;
                addSpeed = 777;
                addAttack = 888;
                addAttackDistance = 999;
                drawableId = R.drawable.item_goodpistol;
                break;


        }


    }
}

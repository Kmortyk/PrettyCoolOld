package com.example.user1.prettycool.Classes.Persons;

import com.example.user1.prettycool.R;


/**
 * Created by user1 on 18.03.2016.
 */
public class MonstersParameters extends Person {



    MonstersParameters(String monsterId){
        switch(monsterId){
            case "Zm":
                NAME = "Zombi-Man";
                HP = 5;
                ATTACK = 1;
                SHIELD = 0;
                SPEED = 1;
                EXP = 500;
                //SPRITE;
                MOVEPOINTS = 1;
                drawableId = R.drawable.monster_redneck;
                ATTACKDISTANCE=1;
                break;

        }
        imHeroNotMonstr = 0;
        }

//
//    public void onDamageGot(int Damage){
//        this.HP-=Damage;
//        if(this.HP<=0){
//            isAlive=false;
//        }
//    }



}
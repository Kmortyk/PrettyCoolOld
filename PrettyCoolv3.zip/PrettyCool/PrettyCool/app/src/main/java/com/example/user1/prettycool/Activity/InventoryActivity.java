//package com.example.user1.prettycool.Activity;
//
//import android.support.v7.app.AppCompatActivity;
//import android.os.Bundle;
//
//import com.example.user1.prettycool.R;
//
//public class InventoryActivity extends AppCompatActivity {
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_inventory);
//    }
//}

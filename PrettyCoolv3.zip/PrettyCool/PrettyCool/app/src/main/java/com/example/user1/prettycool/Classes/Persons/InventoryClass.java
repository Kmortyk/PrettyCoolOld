package com.example.user1.prettycool.Classes.Persons;

import java.util.HashMap;

/**
 * Created by user1 on 24.03.2016.
 */
public class InventoryClass extends HeroParameters{


    AllItems allItems;

     InventoryClass(){

    }




}

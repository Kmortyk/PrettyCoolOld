//package com.example.user1.prettycool.Classes.ViewClasses;
//
//import android.content.Context;
//import android.graphics.Bitmap;
//import android.graphics.Canvas;
//import android.view.View;
//
///**
// * Created by user1 on 24.03.2016.
// */
//public class Objects extends View {
//    Bitmap bitmap;
//
//
//    public Objects(Context context) {
//        super(context);
//    }
//
//
//    @Override
//   public void onDraw(Canvas canvas){
//
//    }
//}

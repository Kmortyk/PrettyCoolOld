//package com.example.user1.prettycool;
//
//import com.example.user1.prettycool.Classes.LevelMap.ItemMaps;
//import com.example.user1.prettycool.Classes.LevelMap.MapLevels;
//import com.example.user1.prettycool.Classes.Persons.GlobalInformation;
//
//import java.util.ArrayList;
//
///**
// * Created by user1 on 30.03.2016.
// */
//public class ObjectsArrayList {
//
//
//    ArrayList viewObjects;
//    ItemMaps itemMaps;
//    MapLevels mapLevels;
//    GlobalInformation globalInformation;
//
//
//    ObjectsArrayList(){
//
//    }
//}

package com.example.user1.prettycool.Classes;

/**
 * Created by user1 on 12.04.2016.
 */
public class Objects {
    public int imHeroNotMonstr=1;
    public int drawableId;
    public int getDrawableId() {
        return drawableId;
    }

    public void setDrawableId(int drawableId) {
        this.drawableId = drawableId;
    }



    public int getImHeroNotMonstr() {
        return imHeroNotMonstr;
    }

    public void setImHeroNotMonstr(int imHeroNotMonstr) {
        this.imHeroNotMonstr = imHeroNotMonstr;
    }


}

package com.vanilla.death.model.decoration;

/**
 * Created by hedgehog on 16.06.17.
 */
public class Decoration {
}

package com.vanilla.death.model.map;



public class Map {
}

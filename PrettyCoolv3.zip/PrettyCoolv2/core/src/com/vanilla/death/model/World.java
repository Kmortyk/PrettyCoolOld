package com.vanilla.death.model;

/**
 * Created by hedgehog on 16.06.17.
 */
public class World {
}

package com.vanilla.death.model.mob;

import com.badlogic.gdx.graphics.Texture;

/**
 * Created by hedgehog on 16.06.17.
 */
public abstract class Mob {
    int x;
    int y;

    Texture texture;



}
